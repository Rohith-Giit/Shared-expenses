
document.addEventListener("DOMContentLoaded", () => {
    const toggleSidebar = document.getElementById("toggleSidebar");
    const sidebar = document.querySelector(".sidebar");

    toggleSidebar.addEventListener("click", () => {
        sidebar.classList.toggle("closed");
    });

    const totalRentEl = document.getElementById("totalRent").querySelector("p");
    const totalExpensesEl = document.getElementById("totalExpenses").querySelector("p");
    const remainingBalanceEl = document.getElementById("remainingBalance").querySelector("p");

    let totalRent = 0;
    let totalExpenses = 0;

    document.getElementById("addContribution").addEventListener("click", () => {
        const name = document.getElementById("contributorName").value;
        const amount = parseFloat(document.getElementById("contributionAmount").value);
        if (name && amount) {
            totalRent += amount;
            totalRentEl.textContent = `$${totalRent}`;
            remainingBalanceEl.textContent = `$${totalRent - totalExpenses}`;
            document.getElementById("contributorName").value = "";
            document.getElementById("contributionAmount").value = "";
        }
    });

    document.getElementById("addExpense").addEventListener("click", () => {
        const name = document.getElementById("expenseName").value;
        const amount = parseFloat(document.getElementById("expenseAmount").value);
        if (name && amount) {
            totalExpenses += amount;
            totalExpensesEl.textContent = `$${totalExpenses}`;
            remainingBalanceEl.textContent = `$${totalRent - totalExpenses}`;
            document.getElementById("expenseName").value = "";
            document.getElementById("expenseAmount").value = "";
            document.getElementById("expenseReceipt").value = "";
        }
    });
});
