import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Receipt as ReceiptIcon, Users as UsersIcon, X, Settings, UserPlus } from 'lucide-react';
import { GroupMember, Transaction, GroceryItem } from '../types';

interface ExpensesSectionProps {
  groupMembers: GroupMember[];
  onAddRoomRent: (amount: number, memberId: string) => void;
  onAddGrocery: (item: Omit<GroceryItem, 'id' | 'date'>) => void;
}

const ExpensesSection: React.FC<ExpensesSectionProps> = ({
  groupMembers: initialGroupMembers,
  onAddRoomRent,
  onAddGrocery
}) => {
  const [activeTab, setActiveTab] = useState<'rent' | 'grocery'>('rent');
  const [rentAmount, setRentAmount] = useState('');
  const [selectedMember, setSelectedMember] = useState('');
  const [groceryName, setGroceryName] = useState('');
  const [groceryQuantity, setGroceryQuantity] = useState('1');
  const [groceryAmount, setGroceryAmount] = useState('');
  const [receipt, setReceipt] = useState<File | null>(null);
  const [showMembersModal, setShowMembersModal] = useState(false);
  const [showAddMember, setShowAddMember] = useState(false);
  const [newMemberName, setNewMemberName] = useState('');
  const [groupMembers, setGroupMembers] = useState(initialGroupMembers);
  const [selectedEmoji, setSelectedEmoji] = useState('👤');

  const emojis = ['👤', '👨‍💻', '👩‍💻', '🧑‍💼', '👨‍💼', '👩‍💼', '👨‍🦰', '👩‍🦰', '👨‍🦱', '👩‍🦱'];

  const handleRentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (rentAmount && selectedMember) {
      onAddRoomRent(parseFloat(rentAmount), selectedMember);
      setRentAmount('');
      setSelectedMember('');
    }
  };

  const handleGrocerySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (groceryName && groceryAmount && selectedMember) {
      onAddGrocery({
        name: groceryName,
        quantity: parseInt(groceryQuantity),
        amount: parseFloat(groceryAmount),
        addedBy: selectedMember,
        receipt: receipt ? URL.createObjectURL(receipt) : undefined
      });
      setGroceryName('');
      setGroceryQuantity('1');
      setGroceryAmount('');
      setSelectedMember('');
      setReceipt(null);
    }
  };

  const handleAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (newMemberName) {
      const newMember = {
        id: `member-${Date.now()}`,
        name: newMemberName,
        emoji: selectedEmoji
      };
      setGroupMembers(prev => [...prev, newMember]);
      setNewMemberName('');
      setSelectedEmoji('👤');
      setShowAddMember(false);
    }
  };

  const handleRemoveMember = (memberId: string) => {
    setGroupMembers(prev => prev.filter(member => member.id !== memberId));
  };

  return (
    <div className="space-y-6">
      <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-4">
            <UsersIcon className="w-6 h-6 text-blue-400" />
            <h2 className="text-xl font-semibold text-white">Group Members</h2>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowMembersModal(true)}
            className="px-4 py-2 bg-blue-500 rounded-xl text-white flex items-center gap-2"
          >
            <Settings className="w-4 h-4" />
            Manage Members
          </motion.button>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {groupMembers.map(member => (
            <motion.div
              key={member.id}
              whileHover={{ scale: 1.05 }}
              className="bg-white/5 backdrop-blur-lg rounded-xl p-4 flex items-center gap-3"
            >
              <span className="text-2xl">{member.emoji}</span>
              <span className="text-white font-medium">{member.name}</span>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Group Members Modal */}
      <AnimatePresence>
        {showMembersModal && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 w-full max-w-2xl"
            >
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-semibold text-white">Manage Group Members</h3>
                <button
                  onClick={() => setShowMembersModal(false)}
                  className="text-white/60 hover:text-white"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="space-y-4 max-h-[60vh] overflow-y-auto">
                {groupMembers.map(member => (
                  <motion.div
                    key={member.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-white/5 backdrop-blur-lg rounded-xl p-4 flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{member.emoji}</span>
                      <span className="text-white font-medium">{member.name}</span>
                    </div>
                    <button
                      onClick={() => handleRemoveMember(member.id)}
                      className="px-3 py-1 bg-rose-500/20 text-rose-400 rounded-lg hover:bg-rose-500/30 transition-colors"
                    >
                      Remove
                    </button>
                  </motion.div>
                ))}
              </div>

              <div className="mt-6 flex gap-4">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => {
                    setShowAddMember(true);
                    setShowMembersModal(false);
                  }}
                  className="flex-1 bg-blue-500 text-white py-3 rounded-xl font-medium flex items-center justify-center gap-2"
                >
                  <UserPlus className="w-5 h-5" />
                  Add New Member
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setShowMembersModal(false)}
                  className="flex-1 bg-white/10 text-white py-3 rounded-xl font-medium"
                >
                  Close
                </motion.button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Add Member Modal */}
      <AnimatePresence>
        {showAddMember && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 w-full max-w-md"
            >
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-semibold text-white">Add New Member</h3>
                <button
                  onClick={() => setShowAddMember(false)}
                  className="text-white/60 hover:text-white"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              <form onSubmit={handleAddMember} className="space-y-4">
                <div>
                  <label className="block text-white/60 text-sm mb-2">Member Name</label>
                  <input
                    type="text"
                    value={newMemberName}
                    onChange={(e) => setNewMemberName(e.target.value)}
                    className="w-full px-4 py-2 bg-white/10 rounded-xl text-white outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter member name"
                    required
                  />
                </div>
                <div>
                  <label className="block text-white/60 text-sm mb-2">Choose Avatar</label>
                  <div className="grid grid-cols-5 gap-2">
                    {emojis.map(emoji => (
                      <button
                        key={emoji}
                        type="button"
                        onClick={() => setSelectedEmoji(emoji)}
                        className={`text-2xl p-2 rounded-lg ${
                          selectedEmoji === emoji ? 'bg-blue-500' : 'bg-white/10'
                        }`}
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="flex gap-4 mt-6">
                  <button
                    type="button"
                    onClick={() => {
                      setShowAddMember(false);
                      setShowMembersModal(true);
                    }}
                    className="flex-1 bg-white/10 text-white py-2 rounded-xl hover:bg-white/20"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 bg-blue-500 text-white py-2 rounded-xl hover:bg-blue-600"
                  >
                    Add Member
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Expense Type Tabs */}
      <div className="flex gap-4">
        <button
          onClick={() => setActiveTab('rent')}
          className={`flex-1 py-3 rounded-xl transition-colors ${
            activeTab === 'rent'
              ? 'bg-blue-500 text-white'
              : 'bg-white/10 text-white/60 hover:text-white'
          }`}
        >
          Add Room Rent
        </button>
        <button
          onClick={() => setActiveTab('grocery')}
          className={`flex-1 py-3 rounded-xl transition-colors ${
            activeTab === 'grocery'
              ? 'bg-green-500 text-white'
              : 'bg-white/10 text-white/60 hover:text-white'
          }`}
        >
          Add Grocery Expense
        </button>
      </div>

      {/* Active Form Section */}
      <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 text-white">
        {activeTab === 'rent' ? (
          <>
            <div className="flex items-center gap-4 mb-6">
              <ReceiptIcon className="w-6 h-6 text-blue-400" />
              <h3 className="text-xl font-semibold text-white">Add Room Rent</h3>
            </div>
            <form onSubmit={handleRentSubmit} className="space-y-4">
              <div>
                <label className="block text-white/60 text-sm mb-2">Select Member</label>
                <select
                  value={selectedMember}
                  onChange={(e) => setSelectedMember(e.target.value)}
                  className="w-full px-4 py-2 bg-white/10 rounded-xl text-white outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="">Choose a member</option>
                  {groupMembers.map(member => (
                    <option key={member.id} value={member.id}>
                      {member.emoji} {member.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-white/60 text-sm mb-2">Amount (£)</label>
                <input
                  type="number"
                  value={rentAmount}
                  onChange={(e) => setRentAmount(e.target.value)}
                  className="w-full px-4 py-2 bg-white/10 rounded-xl text-white outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Enter amount"
                  required
                />
              </div>
              
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                type="submit"
                className="w-full bg-blue-500 text-white py-3 rounded-xl font-medium flex items-center justify-center gap-2"
              >
                <Plus className="w-5 h-5" />
                Add Rent Payment
              </motion.button>
            </form>
          </>
        ) : (
          <>
            <div className="flex items-center gap-4 mb-6">
              <ReceiptIcon className="w-6 h-6 text-green-400" />
              <h3 className="text-xl font-semibold text-white">Add Grocery Expense</h3>
            </div>
            <form onSubmit={handleGrocerySubmit} className="space-y-4">
              <div>
                <label className="block text-white/60 text-sm mb-2">Select Member</label>
                <select
                  value={selectedMember}
                  onChange={(e) => setSelectedMember(e.target.value)}
                  className="w-full px-4 py-2 bg-white/10 rounded-xl text-white outline-none focus:ring-2 focus:ring-green-500"
                  required
                >
                  <option value="">Choose a member</option>
                  {groupMembers.map(member => (
                    <option key={member.id} value={member.id}>
                      {member.emoji} {member.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-white/60 text-sm mb-2">Grocery Item Name</label>
                <input
                  type="text"
                  value={groceryName}
                  onChange={(e) => setGroceryName(e.target.value)}
                  className="w-full px-4 py-2 bg-white/10 rounded-xl text-white outline-none focus:ring-2 focus:ring-green-500"
                  placeholder="Enter item name"
                  required
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-white/60 text-sm mb-2">Quantity</label>
                  <input
                    type="number"
                    value={groceryQuantity}
                    onChange={(e) => setGroceryQuantity(e.target.value)}
                    className="w-full px-4 py-2 bg-white/10 rounded-xl text-white outline-none focus:ring-2 focus:ring-green-500"
                    min="1"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-white/60 text-sm mb-2">Amount (£)</label>
                  <input
                    type="number"
                    value={groceryAmount}
                    onChange={(e) => setGroceryAmount(e.target.value)}
                    className="w-full px-4 py-2 bg-white/10 rounded-xl text-white outline-none focus:ring-2 focus:ring-green-500"
                    placeholder="Enter amount"
                    required
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-white/60 text-sm mb-2">Receipt (Optional)</label>
                <div className="border-2 border-dashed border-white/20 rounded-xl p-6 text-center cursor-pointer hover:border-white/40 transition-colors">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => setReceipt(e.target.files?.[0] || null)}
                    className="hidden"
                    id="receipt"
                  />
                  <label htmlFor="receipt" className="cursor-pointer">
                    <div className="text-4xl mb-2">📸</div>
                    <p className="text-white/60">
                      {receipt ? receipt.name : 'Click to upload receipt'}
                    </p>
                  </label>
                </div>
              </div>
              
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                type="submit"
                className="w-full bg-green-500 text-white py-3 rounded-xl font-medium flex items-center justify-center gap-2"
              >
                <Plus className="w-5 h-5" />
                Add Grocery Expense
              </motion.button>
            </form>
          </>
        )}
      </div>
    </div>
  );
};

export default ExpensesSection;