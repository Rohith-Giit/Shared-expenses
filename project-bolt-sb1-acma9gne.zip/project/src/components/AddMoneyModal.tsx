import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, CreditCard, Wallet } from 'lucide-react';

interface AddMoneyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (amount: number) => void;
}

const AddMoneyModal: React.FC<AddMoneyModalProps> = ({ isOpen, onClose, onAdd }) => {
  const [amount, setAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'bank'>('card');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (amount) {
      onAdd(parseFloat(amount));
      setAmount('');
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 w-full max-w-md relative"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-white/60 hover:text-white"
        >
          <X className="w-6 h-6" />
        </button>

        <h2 className="text-2xl font-semibold text-white mb-6">Add Money</h2>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-white/60 text-sm mb-2">Payment Method</label>
            <div className="grid grid-cols-2 gap-4">
              <button
                type="button"
                onClick={() => setPaymentMethod('card')}
                className={`p-4 rounded-xl flex flex-col items-center gap-2 ${
                  paymentMethod === 'card' ? 'bg-blue-500' : 'bg-white/10'
                }`}
              >
                <CreditCard className="w-6 h-6" />
                <span>Card</span>
              </button>
              <button
                type="button"
                onClick={() => setPaymentMethod('bank')}
                className={`p-4 rounded-xl flex flex-col items-center gap-2 ${
                  paymentMethod === 'bank' ? 'bg-blue-500' : 'bg-white/10'
                }`}
              >
                <Wallet className="w-6 h-6" />
                <span>Bank Transfer</span>
              </button>
            </div>
          </div>

          <div>
            <label className="block text-white/60 text-sm mb-2">Amount (£)</label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full px-4 py-2 bg-white/10 rounded-xl text-white outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter amount"
              min="0.01"
              step="0.01"
              required
            />
          </div>

          <div className="pt-4">
            <button
              type="submit"
              className="w-full bg-blue-500 text-white py-3 rounded-xl font-medium hover:bg-blue-600 transition-colors"
            >
              Add Money
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

export default AddMoneyModal;