import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Mail, Key, UserPlus, LogIn, Hash } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type AuthMethod = 'email' | 'code';

const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [authMethod, setAuthMethod] = useState<AuthMethod>('email');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [uniqueCode, setUniqueCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    if (authMethod === 'email') {
      // Basic validation for email login
      if (!email || !password) {
        setError('Please fill in all fields');
        setLoading(false);
        return;
      }

      if (!isLogin && password !== confirmPassword) {
        setError('Passwords do not match');
        setLoading(false);
        return;
      }
    } else {
      // Validation for unique code login
      if (!uniqueCode) {
        setError('Please enter your unique code');
        setLoading(false);
        return;
      }

      // Here you would typically validate the unique code format
      if (uniqueCode.length < 6) {
        setError('Unique code must be at least 6 characters');
        setLoading(false);
        return;
      }
    }

    // Simulate authentication
    setTimeout(() => {
      if (isLogin) {
        // Demo login success
        setSuccess('Successfully logged in!');
        localStorage.setItem('user', JSON.stringify({ 
          email: authMethod === 'email' ? email : `user-${uniqueCode}@example.com`,
          uniqueCode: authMethod === 'code' ? uniqueCode : undefined
        }));
        onClose();
      } else {
        // Demo registration success
        setSuccess('Account created successfully! You can now log in.');
        setIsLogin(true);
      }
      setLoading(false);
    }, 1000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 w-full max-w-md relative"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-white/60 hover:text-white"
        >
          <X className="w-6 h-6" />
        </button>

        <h2 className="text-2xl font-semibold text-white mb-2">
          {isLogin ? 'Welcome Back' : 'Create Account'}
        </h2>
        <p className="text-white/60 mb-6">
          {isLogin 
            ? 'Sign in to access your account' 
            : 'Sign up to start managing your finances'}
        </p>

        {isLogin && (
          <div className="mb-6">
            <label className="block text-white/60 text-sm mb-2">Sign in with</label>
            <div className="grid grid-cols-2 gap-4">
              <button
                type="button"
                onClick={() => setAuthMethod('email')}
                className={`p-4 rounded-xl flex flex-col items-center gap-2 ${
                  authMethod === 'email' ? 'bg-blue-500' : 'bg-white/10'
                }`}
              >
                <Mail className="w-6 h-6" />
                <span>Email</span>
              </button>
              <button
                type="button"
                onClick={() => setAuthMethod('code')}
                className={`p-4 rounded-xl flex flex-col items-center gap-2 ${
                  authMethod === 'code' ? 'bg-blue-500' : 'bg-white/10'
                }`}
              >
                <Hash className="w-6 h-6" />
                <span>Unique Code</span>
              </button>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {authMethod === 'email' ? (
            <>
              <div>
                <label className="block text-white/60 text-sm mb-2">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/40" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-12 pr-4 py-2 bg-white/10 rounded-xl text-white outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter your email"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-white/60 text-sm mb-2">Password</label>
                <div className="relative">
                  <Key className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/40" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-12 pr-4 py-2 bg-white/10 rounded-xl text-white outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Enter your password"
                    required
                  />
                </div>
              </div>

              {!isLogin && (
                <div>
                  <label className="block text-white/60 text-sm mb-2">Confirm Password</label>
                  <div className="relative">
                    <Key className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/40" />
                    <input
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full pl-12 pr-4 py-2 bg-white/10 rounded-xl text-white outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Confirm your password"
                      required
                    />
                  </div>
                </div>
              )}
            </>
          ) : (
            <div>
              <label className="block text-white/60 text-sm mb-2">Unique Code</label>
              <div className="relative">
                <Hash className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/40" />
                <input
                  type="text"
                  value={uniqueCode}
                  onChange={(e) => setUniqueCode(e.target.value)}
                  className="w-full pl-12 pr-4 py-2 bg-white/10 rounded-xl text-white outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Enter your unique code"
                  required
                />
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2 bg-blue-500 text-white rounded-xl hover:bg-blue-600 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {loading ? (
              'Processing...'
            ) : isLogin ? (
              <>
                <LogIn className="w-5 h-5" />
                Sign In
              </>
            ) : (
              <>
                <UserPlus className="w-5 h-5" />
                Create Account
              </>
            )}
          </button>

          {authMethod === 'email' && (
            <button
              type="button"
              onClick={() => {
                setIsLogin(!isLogin);
                setError('');
                setSuccess('');
              }}
              className="w-full py-2 bg-white/10 text-white rounded-xl hover:bg-white/20 transition-colors"
            >
              {isLogin ? "Don't have an account? Sign Up" : 'Already have an account? Sign In'}
            </button>
          )}
        </form>

        {error && (
          <p className="mt-4 text-rose-400 text-sm">{error}</p>
        )}

        {success && (
          <p className="mt-4 text-emerald-400 text-sm">{success}</p>
        )}
      </motion.div>
    </div>
  );
};

export default AuthModal;