import React from 'react';

interface VirtualCardProps {
  holderName: string;
  isVisible: boolean;
  balance: number;
}

const VirtualCard: React.FC<VirtualCardProps> = ({ holderName, isVisible, balance }) => {
  return (
    <div className={`virtual-card-container ${isVisible ? 'show' : 'hidden'}`}>
      <div className="virtual-card bg-gradient-to-br from-gray-900 to-black p-8 rounded-3xl shadow-2xl relative overflow-hidden">
        {/* Animated background pattern */}
        <div className="absolute inset-0 opacity-20">
          <div className="grid grid-cols-8 gap-2 h-full">
            {Array.from({ length: 64 }).map((_, i) => (
              <div key={i} className="bg-white/10 rounded-full animate-pulse" style={{
                animationDelay: `${i * 0.1}s`
              }}></div>
            ))}
          </div>
        </div>

        {/* Card content */}
        <div className="relative z-10">
          <div className="flex justify-between items-start mb-12">
            <div className="text-white/80 text-sm px-3 py-1 bg-white/10 rounded-full">
              Virtual Card
            </div>
            <div className="text-white font-bold text-xl">
              NOTEBUDGET
            </div>
          </div>

          <div className="mb-8">
            <div className="text-white/60 text-sm mb-1">Card Holder</div>
            <div className="text-white text-2xl font-bold tracking-wider">
              {holderName}
            </div>
          </div>

          <div className="mb-8">
            <div className="text-white/60 text-sm mb-1">Available Balance</div>
            <div className="text-white text-3xl font-bold">
              £{balance.toLocaleString()}
            </div>
          </div>

          <div className="flex justify-between items-end">
            <div className="text-white/60 text-sm">
              <div>Valid Thru</div>
              <div className="text-white font-medium">∞</div>
            </div>
            <div className="flex space-x-2">
              <div className="w-8 h-8 bg-red-500 rounded-full"></div>
              <div className="w-8 h-8 bg-orange-500 rounded-full opacity-80"></div>
            </div>
          </div>
        </div>

        {/* Holographic effect */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent animate-shimmer"></div>
      </div>

      {/* Card actions */}
      <div className="mt-6 grid grid-cols-3 gap-4">
        <button className="card-action-btn">
          <span className="text-2xl">👁️</span>
          <span>Show Details</span>
        </button>
        <button className="card-action-btn">
          <span className="text-2xl">❄️</span>
          <span>Freeze Card</span>
        </button>
        <button className="card-action-btn">
          <span className="text-2xl">⚙️</span>
          <span>Settings</span>
        </button>
      </div>

      {/* Add to wallet button */}
      <button className="mt-6 w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-3 rounded-xl flex items-center justify-center space-x-2 hover:from-blue-700 hover:to-blue-800 transition-all">
        <span className="text-xl">📱</span>
        <span>Add to Apple Wallet</span>
      </button>
    </div>
  );
};

export default VirtualCard;