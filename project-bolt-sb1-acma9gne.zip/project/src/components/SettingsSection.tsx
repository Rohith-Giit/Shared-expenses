import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Moon, Sun, Globe, User, Trash2, RotateCcw, ChevronDown, LogIn } from 'lucide-react';

interface SettingsSectionProps {
  onResetData: () => void;
  onUndoLastTransaction: () => void;
  onThemeChange: (theme: 'light' | 'dark' | 'system') => void;
  onLanguageChange: (language: string) => void;
  currentTheme: 'light' | 'dark' | 'system';
  currentLanguage: string;
  onSignIn: () => void;
  user: any;
}

const SettingsSection: React.FC<SettingsSectionProps> = ({
  onResetData,
  onUndoLastTransaction,
  onThemeChange,
  onLanguageChange,
  currentTheme,
  currentLanguage,
  onSignIn,
  user
}) => {
  const [showConfirmReset, setShowConfirmReset] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  const languages = [
    { code: 'en', name: 'English' },
    { code: 'es', name: 'Español' },
    { code: 'fr', name: 'Français' },
    { code: 'de', name: 'Deutsch' },
    { code: 'hi', name: 'हिंदी' }
  ];

  const handleResetConfirm = () => {
    onResetData();
    setShowConfirmReset(false);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 text-white">
        <h2 className="text-2xl font-semibold mb-6">Account</h2>
        {user ? (
          <div className="flex items-center gap-4 mb-6">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-3xl">
              {user.email.charAt(0).toUpperCase()}
            </div>
            <div>
              <h3 className="text-xl font-semibold">{user.email}</h3>
              {user.uniqueCode && (
                <p className="text-white/60">Code: {user.uniqueCode}</p>
              )}
            </div>
          </div>
        ) : (
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onSignIn}
            className="w-full bg-blue-500 text-white py-3 rounded-xl font-medium flex items-center justify-center gap-2"
          >
            <LogIn className="w-5 h-5" />
            Sign In
          </motion.button>
        )}
      </div>

      <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 text-white">
        <h2 className="text-2xl font-semibold mb-6">Appearance</h2>
        <div className="grid grid-cols-3 gap-4">
          {(['light', 'dark', 'system'] as const).map((theme) => (
            <motion.button
              key={theme}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => onThemeChange(theme)}
              className={`p-4 rounded-xl flex flex-col items-center gap-2 ${
                currentTheme === theme ? 'bg-blue-500' : 'bg-white/10'
              }`}
            >
              {theme === 'light' ? (
                <Sun className="w-6 h-6" />
              ) : theme === 'dark' ? (
                <Moon className="w-6 h-6" />
              ) : (
                <div className="flex">
                  <Sun className="w-6 h-6" />
                  <Moon className="w-6 h-6" />
                </div>
              )}
              <span className="capitalize">{theme}</span>
            </motion.button>
          ))}
        </div>
      </div>

      <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 text-white">
        <h2 className="text-2xl font-semibold mb-6">Language</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          {languages.map((lang) => (
            <motion.button
              key={lang.code}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => onLanguageChange(lang.code)}
              className={`p-4 rounded-xl flex items-center gap-3 ${
                currentLanguage === lang.code ? 'bg-blue-500' : 'bg-white/10'
              }`}
            >
              <Globe className="w-5 h-5" />
              <span>{lang.name}</span>
            </motion.button>
          ))}
        </div>
      </div>

      <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 text-white">
        <h2 className="text-2xl font-semibold mb-6">Data Management</h2>
        <div className="space-y-4">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onUndoLastTransaction}
            className="w-full bg-white/10 text-white py-3 rounded-xl font-medium flex items-center justify-center gap-2"
          >
            <RotateCcw className="w-5 h-5" />
            Undo Last Transaction
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setShowConfirmReset(true)}
            className="w-full bg-rose-500/20 text-rose-400 py-3 rounded-xl font-medium flex items-center justify-center gap-2"
          >
            <Trash2 className="w-5 h-5" />
            Reset All Data
          </motion.button>
        </div>
      </div>

      {/* Reset Confirmation Modal */}
      {showConfirmReset && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 w-full max-w-md"
          >
            <h3 className="text-xl font-semibold text-white mb-4">Reset All Data?</h3>
            <p className="text-white/60 mb-6">
              This action cannot be undone. All your transactions and settings will be permanently deleted.
            </p>
            <div className="flex gap-4">
              <button
                onClick={() => setShowConfirmReset(false)}
                className="flex-1 bg-white/10 text-white py-2 rounded-xl hover:bg-white/20"
              >
                Cancel
              </button>
              <button
                onClick={handleResetConfirm}
                className="flex-1 bg-rose-500 text-white py-2 rounded-xl hover:bg-rose-600"
              >
                Reset
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};

export default SettingsSection;