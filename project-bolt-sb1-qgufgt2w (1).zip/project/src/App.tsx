import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Wallet, Home, PieChart, Receipt, Users, Settings,
  TrendingUp, ArrowUpRight, ArrowDownRight,
  Plus, Send, FileDown, CreditCard, History
} from 'lucide-react';
import { format } from 'date-fns';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import VirtualCard from './components/VirtualCard';
import SendMoneyModal from './components/SendMoneyModal';
import ExpensesSection from './components/ExpensesSection';
import AuthModal from './components/AuthModal';
import SettingsSection from './components/SettingsSection';
import AddMoneyModal from './components/AddMoneyModal';
import ExportDataModal from './components/ExportDataModal';
import { v4 as uuidv4 } from 'uuid';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [walletTab, setWalletTab] = useState<'card' | 'transactions'>('card');
  const [isCardVisible, setIsCardVisible] = useState(false);
  const [isSendMoneyModalOpen, setIsSendMoneyModalOpen] = useState(false);
  const [isAddMoneyModalOpen, setIsAddMoneyModalOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [user, setUser] = useState(null);
  const [theme, setTheme] = useState<'light' | 'dark' | 'system'>('system');
  const [language, setLanguage] = useState('en');
  const [transactionHistory, setTransactionHistory] = useState<any[]>([]);
  
  const [transactions, setTransactions] = useState(() => {
    const saved = localStorage.getItem('transactions');
    return saved ? JSON.parse(saved) : [];
  });

  const balance = transactions.reduce((total, transaction) => {
    return transaction.type === 'income' 
      ? total + transaction.amount 
      : total - transaction.amount;
  }, 0);

  const expenses = transactions
    .filter(transaction => {
      const transactionDate = new Date(transaction.created_at);
      const currentDate = new Date();
      return (
        transaction.type === 'expense' &&
        transactionDate.getMonth() === currentDate.getMonth() &&
        transactionDate.getFullYear() === currentDate.getFullYear()
      );
    })
    .reduce((total, transaction) => total + transaction.amount, 0);

  const remainingBalance = balance - expenses;

  const chartData = React.useMemo(() => {
    const monthlyData = new Map();
    let runningBalance = 0;

    const sortedTransactions = [...transactions].sort((a, b) => 
      new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
    );

    sortedTransactions.forEach(transaction => {
      const date = new Date(transaction.created_at);
      const monthKey = format(date, 'MMM');
      
      runningBalance = transaction.type === 'income'
        ? runningBalance + transaction.amount
        : runningBalance - transaction.amount;
      
      monthlyData.set(monthKey, runningBalance);
    });

    return Array.from(monthlyData.entries()).map(([name, value]) => ({
      name,
      value
    }));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    document.documentElement.classList.remove('light', 'dark');
    if (theme === 'system') {
      const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
      document.documentElement.classList.add(systemTheme);
    } else {
      document.documentElement.classList.add(theme);
    }
  }, [theme]);

  useEffect(() => {
    document.documentElement.lang = language;
  }, [language]);

  useEffect(() => {
    const handleOpenAuthModal = () => {
      setIsAuthModalOpen(true);
    };

    window.addEventListener('open-auth-modal', handleOpenAuthModal);
    return () => {
      window.removeEventListener('open-auth-modal', handleOpenAuthModal);
    };
  }, []);

  const handleNewTransaction = (type: 'income' | 'expense', amount: number, description: string) => {
    const newTransaction = {
      id: uuidv4(),
      type,
      amount,
      description,
      created_at: new Date().toISOString()
    };

    setTransactions(prev => {
      const newTransactions = [newTransaction, ...prev];
      setTransactionHistory(prev => [...prev, newTransactions]);
      return newTransactions;
    });
  };

  const handleResetData = () => {
    setTransactions([]);
    setTransactionHistory([]);
    localStorage.removeItem('transactions');
  };

  const handleUndoLastTransaction = () => {
    if (transactionHistory.length > 0) {
      const previousState = transactionHistory[transactionHistory.length - 2] || [];
      setTransactions(previousState);
      setTransactionHistory(prev => prev.slice(0, -1));
    }
  };

  const handleThemeChange = (newTheme: 'light' | 'dark' | 'system') => {
    setTheme(newTheme);
  };

  const handleLanguageChange = (newLanguage: string) => {
    setLanguage(newLanguage);
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(120,119,198,0.3),rgba(255,255,255,0))]">
      <nav className="fixed top-0 left-0 h-full w-20 bg-white/10 backdrop-blur-lg flex flex-col items-center py-8 space-y-8">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center"
        >
          <Wallet className="w-6 h-6 text-white" />
        </motion.div>

        {[
          { icon: Home, label: 'Dashboard', id: 'dashboard' },
          { icon: PieChart, label: 'Analytics', id: 'analytics' },
          { icon: Wallet, label: 'Wallet', id: 'transactions' },
          { icon: Users, label: 'Expenses', id: 'expenses' },
          { icon: Settings, label: 'Settings', id: 'settings' },
        ].map(({ icon: Icon, label, id }) => (
          <motion.button
            key={id}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setActiveTab(id)}
            className={`w-12 h-12 rounded-xl flex flex-col items-center justify-center ${
              activeTab === id
                ? 'bg-blue-500 text-white'
                : 'text-white/60 hover:text-white'
            }`}
          >
            <Icon className="w-5 h-5" />
            <span className="text-[10px] mt-1">{label}</span>
          </motion.button>
        ))}
      </nav>

      <main className="ml-20 p-8 pt-20">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="max-w-7xl mx-auto"
          >
            {activeTab === 'dashboard' && (
              <div className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 text-white"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <TrendingUp className="w-6 h-6 text-emerald-400" />
                      <span className="text-emerald-400 flex items-center">
                        <ArrowUpRight className="w-4 h-4 mr-1" />
                        {chartData.length > 1 
                          ? ((chartData[chartData.length - 1].value - chartData[0].value) / Math.abs(chartData[0].value) * 100).toFixed(1)
                          : '0'}%
                      </span>
                    </div>
                    <h3 className="text-lg text-white/60">Total Balance</h3>
                    <p className="text-3xl font-bold">£{balance.toLocaleString()}</p>
                  </motion.div>

                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 text-white"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <Receipt className="w-6 h-6 text-rose-400" />
                      <span className="text-rose-400 flex items-center">
                        <ArrowDownRight className="w-4 h-4 mr-1" />
                        {balance > 0 ? ((expenses / balance) * 100).toFixed(1) : '0'}%
                      </span>
                    </div>
                    <h3 className="text-lg text-white/60">Monthly Expenses</h3>
                    <p className="text-3xl font-bold">£{expenses.toLocaleString()}</p>
                  </motion.div>

                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 text-white"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <PieChart className="w-6 h-6 text-blue-400" />
                      <span className="text-blue-400">
                        {balance > 0 ? ((remainingBalance / balance) * 100).toFixed(1) : '0'}%
                      </span>
                    </div>
                    <h3 className="text-lg text-white/60">Remaining Balance</h3>
                    <p className="text-3xl font-bold">£{remainingBalance.toLocaleString()}</p>
                  </motion.div>
                </div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 text-white"
                >
                  <h3 className="text-xl font-semibold mb-6">Balance Overview</h3>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={chartData}>
                        <XAxis dataKey="name" stroke="#fff" />
                        <YAxis stroke="#fff" />
                        <Tooltip />
                        <Line
                          type="monotone"
                          dataKey="value"
                          stroke="#3b82f6"
                          strokeWidth={2}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </motion.div>
              </div>
            )}

            {activeTab === 'analytics' && (
              <div className="space-y-8">
                <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 text-white">
                  <h3 className="text-xl font-semibold mb-6">Monthly Spending Analysis</h3>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={chartData}>
                        <XAxis dataKey="name" stroke="#fff" />
                        <YAxis stroke="#fff" />
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: 'rgba(255, 255, 255, 0.1)',
                            border: 'none',
                            borderRadius: '8px',
                            color: '#fff'
                          }}
                        />
                        <Line
                          type="monotone"
                          dataKey="value"
                          stroke="#3b82f6"
                          strokeWidth={2}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 text-white">
                    <h3 className="text-xl font-semibold mb-6">Room Rent Payments</h3>
                    <div className="space-y-4">
                      {transactions
                        .filter(t => t.description.startsWith('Room Rent'))
                        .map(transaction => (
                          <motion.div
                            key={transaction.id}
                            whileHover={{ x: 4 }}
                            className="flex items-center justify-between p-4 rounded-xl bg-white/5"
                          >
                            <div>
                              <p className="font-medium">{transaction.description}</p>
                              <p className="text-sm text-white/60">
                                {format(new Date(transaction.created_at), 'MMM dd, yyyy')}
                              </p>
                            </div>
                            <p className="font-semibold text-emerald-400">
                              +£{transaction.amount.toLocaleString()}
                            </p>
                          </motion.div>
                        ))}
                    </div>
                  </div>

                  <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 text-white">
                    <h3 className="text-xl font-semibold mb-6">Grocery Expenses</h3>
                    <div className="space-y-4">
                      {transactions
                        .filter(t => t.description.startsWith('Grocery'))
                        .map(transaction => (
                          <motion.div
                            key={transaction.id}
                            whileHover={{ x: 4 }}
                            className="flex items-center justify-between p-4 rounded-xl bg-white/5"
                          >
                            <div>
                              <p className="font-medium">{transaction.description}</p>
                              <p className="text-sm text-white/60">
                                {format(new Date(transaction.created_at), 'MMM dd, yyyy')}
                              </p>
                            </div>
                            <p className="font-semibold text-rose-400">
                              -£{transaction.amount.toLocaleString()}
                            </p>
                          </motion.div>
                        ))}
                    </div>
                  </div>
                </div>

                <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 text-white">
                  <h3 className="text-xl font-semibold mb-6">Monthly Summary</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="p-4 bg-white/5 rounded-xl">
                      <p className="text-white/60 mb-2">Total Room Rent</p>
                      <p className="text-2xl font-bold text-emerald-400">
                        +£{transactions
                          .filter(t => t.description.startsWith('Room Rent'))
                          .reduce((sum, t) => sum + t.amount, 0)
                          .toLocaleString()}
                      </p>
                    </div>
                    <div className="p-4 bg-white/5 rounded-xl">
                      <p className="text-white/60 mb-2">Total Groceries</p>
                      <p className="text-2xl font-bold text-rose-400">
                        -£{transactions
                          .filter(t => t.description.startsWith('Grocery'))
                          .reduce((sum, t) => sum + t.amount, 0)
                          .toLocaleString()}
                      </p>
                    </div>
                    <div className="p-4 bg-white/5 rounded-xl">
                      <p className="text-white/60 mb-2">Other Expenses</p>
                      <p className="text-2xl font-bold text-rose-400">
                        -£{transactions
                          .filter(t => !t.description.startsWith('Room Rent') && !t.description.startsWith('Grocery'))
                          .reduce((sum, t) => t.type === 'expense' ? sum + t.amount : sum, 0)
                          .toLocaleString()}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'expenses' && (
              <ExpensesSection
                groupMembers={[
                  { id: '1', name: 'Rohith', emoji: '👨‍💻' },
                  { id: '2', name: 'John', emoji: '🧑‍💼' },
                  { id: '3', name: 'Sarah', emoji: '👩‍💼' },
                  { id: '4', name: 'Mike', emoji: '👨‍🦰' }
                ]}
                onAddRoomRent={(amount, memberId) => {
                  handleNewTransaction('income', amount, `Room Rent - ${memberId}`);
                }}
                onAddGrocery={(item) => {
                  handleNewTransaction('expense', item.amount, `Grocery - ${item.name}`);
                }}
              />
            )}

            {activeTab === 'transactions' && (
              <div className="space-y-8">
                <div className="flex gap-4">
                  <button
                    onClick={() => setWalletTab('card')}
                    className={`flex-1 py-3 rounded-xl transition-colors flex items-center justify-center gap-2 ${
                      walletTab === 'card'
                        ? 'bg-blue-500 text-white'
                        : 'bg-white/10 text-white/60 hover:text-white'
                    }`}
                  >
                    <CreditCard className="w-5 h-5" />
                    Virtual Card
                  </button>
                  <button
                    onClick={() => setWalletTab('transactions')}
                    className={`flex-1 py-3 rounded-xl transition-colors flex items-center justify-center gap-2 ${
                      walletTab === 'transactions'
                        ? 'bg-blue-500 text-white'
                        : 'bg-white/10 text-white/60 hover:text-white'
                    }`}
                  >
                    <History className="w-5 h-5" />
                    Transactions
                  </button>
                </div>

                {walletTab === 'card' ? (
                  <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 text-white">
                    <div className="flex justify-between items-center mb-8">
                      <h2 className="text-2xl font-semibold">Virtual Card</h2>
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => setIsCardVisible(!isCardVisible)}
                        className="px-4 py-2 bg-blue-500 rounded-xl text-white"
                      >
                        {isCardVisible ? 'Hide Card' : 'Show Card'}
                      </motion.button>
                    </div>
                    <VirtualCard 
                      holderName="Rohith Daripelly" 
                      isVisible={isCardVisible} 
                      balance={balance}
                    />
                  </div>
                ) : (
                  <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 text-white">
                    <h2 className="text-2xl font-semibold mb-6">Recent Transactions</h2>
                    <div className="space-y-4">
                      {transactions.slice(0, 10).map(transaction => (
                        <motion.div
                          key={transaction.id}
                          whileHover={{ x: 4 }}
                          className="flex items-center justify-between p-4 rounded-xl bg-white/5"
                        >
                          <div>
                            <p className="font-medium">{transaction.description}</p>
                            <p className="text-sm text-white/60">
                              {format(new Date(transaction.created_at), 'MMM dd, yyyy')}
                            </p>
                          </div>
                          <p className={`font-semibold ${
                            transaction.type === 'income' 
                              ? 'text-emerald-400' 
                              : 'text-rose-400'
                          }`}>
                            {transaction.type === 'income' ? '+' : '-'}
                            £{transaction.amount.toLocaleString()}
                          </p>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setIsAddMoneyModalOpen(true)}
                    className="bg-blue-500 text-white py-4 rounded-xl font-medium flex items-center justify-center gap-2"
                  >
                    <Plus className="w-5 h-5" />
                    Add Money
                  </motion.button>

                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setIsSendMoneyModalOpen(true)}
                    className="bg-green-500 text-white py-4 rounded-xl font-medium flex items-center justify-center gap-2"
                  >
                    <Send className="w-5 h-5" />
                    Send Money
                  </motion.button>
                </div>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setIsExportModalOpen(true)}
                  className="w-full bg-white/10 text-white py-4 rounded-xl font-medium flex items-center justify-center gap-2"
                >
                  <FileDown className="w-5 h-5" />
                  Export Transactions
                </motion.button>
              </div>
            )}

            {activeTab === 'settings' && (
              <SettingsSection
                onResetData={handleResetData}
                onUndoLastTransaction={handleUndoLastTransaction}
                onThemeChange={handleThemeChange}
                onLanguageChange={handleLanguageChange}
                currentTheme={theme}
                currentLanguage={language}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      <SendMoneyModal
        isOpen={isSendMoneyModalOpen}
        onClose={() => setIsSendMoneyModalOpen(false)}
        onSend={(data) => {
          handleNewTransaction('expense', data.amount, `Transfer to ${data.recipientName}`);
          setIsSendMoneyModalOpen(false);
        }}
      />

      <AddMoneyModal
        isOpen={isAddMoneyModalOpen}
        onClose={() => setIsAddMoneyModalOpen(false)}
        onAdd={(amount) => {
          handleNewTransaction('income', amount, 'Added to wallet');
          setIsAddMoneyModalOpen(false);
        }}
      />

      <ExportDataModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        transactions={transactions}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />
    </div>
  );
}

export default App;