import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, FileDown, Calendar } from 'lucide-react';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { format } from 'date-fns';

interface Transaction {
  id: string;
  type: 'income' | 'expense';
  amount: number;
  description: string;
  created_at: string;
}

interface ExportDataModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactions: Transaction[];
}

const ExportDataModal: React.FC<ExportDataModalProps> = ({ isOpen, onClose, transactions }) => {
  const [dateRange, setDateRange] = useState<'all' | 'month' | 'year'>('month');

  const getFilteredTransactions = () => {
    const now = new Date();
    return transactions.filter(transaction => {
      const transactionDate = new Date(transaction.created_at);
      if (dateRange === 'month') {
        return (
          transactionDate.getMonth() === now.getMonth() &&
          transactionDate.getFullYear() === now.getFullYear()
        );
      } else if (dateRange === 'year') {
        return transactionDate.getFullYear() === now.getFullYear();
      }
      return true;
    });
  };

  const handleExport = () => {
    const doc = new jsPDF();
    const filteredTransactions = getFilteredTransactions();

    // Add title
    doc.setFontSize(20);
    doc.text('Transaction Report', 14, 22);

    // Add date range
    doc.setFontSize(12);
    doc.text(`Date Range: ${dateRange.charAt(0).toUpperCase() + dateRange.slice(1)}`, 14, 32);

    // Add total balance
    const balance = filteredTransactions.reduce(
      (sum, t) => sum + (t.type === 'income' ? t.amount : -t.amount),
      0
    );
    doc.text(`Balance: £${balance.toFixed(2)}`, 14, 42);

    // Create table
    const tableData = filteredTransactions.map(t => [
      format(new Date(t.created_at), 'dd/MM/yyyy'),
      t.description,
      t.type,
      `£${t.amount.toFixed(2)}`,
    ]);

    (doc as any).autoTable({
      startY: 50,
      head: [['Date', 'Description', 'Type', 'Amount']],
      body: tableData,
      theme: 'striped',
      headStyles: { fillColor: [59, 130, 246] },
    });

    // Save the PDF
    doc.save(`transactions-${dateRange}-${format(new Date(), 'yyyy-MM-dd')}.pdf`);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 w-full max-w-md relative"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-white/60 hover:text-white"
        >
          <X className="w-6 h-6" />
        </button>

        <h2 className="text-2xl font-semibold text-white mb-6">Export Transactions</h2>

        <div className="space-y-6">
          <div>
            <label className="block text-white/60 text-sm mb-2">Select Date Range</label>
            <div className="grid grid-cols-3 gap-4">
              {(['month', 'year', 'all'] as const).map((range) => (
                <button
                  key={range}
                  type="button"
                  onClick={() => setDateRange(range)}
                  className={`p-4 rounded-xl flex flex-col items-center gap-2 ${
                    dateRange === range ? 'bg-blue-500' : 'bg-white/10'
                  }`}
                >
                  <Calendar className="w-6 h-6" />
                  <span className="capitalize">{range}</span>
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={handleExport}
            className="w-full bg-blue-500 text-white py-3 rounded-xl font-medium hover:bg-blue-600 transition-colors flex items-center justify-center gap-2"
          >
            <FileDown className="w-5 h-5" />
            Export as PDF
          </button>
        </div>
      </motion.div>
    </div>
  );
};

export default ExportDataModal;