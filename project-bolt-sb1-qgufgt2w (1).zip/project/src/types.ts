export interface GroupMember {
  id: string;
  name: string;
  emoji: string;
}

export interface Transaction {
  id: string;
  type: 'contribution' | 'expense' | 'grocery';
  amount: number;
  description: string;
  date: string;
  memberId: string;
  receipt?: string;
}

export interface BankTransfer {
  id: string;
  recipientName: string;
  sortCode: string;
  accountNumber: string;
  amount: number;
  reference?: string;
  date: string;
}

export interface GroceryItem {
  id: string;
  name: string;
  quantity: number;
  amount: number;
  receipt?: string;
  date: string;
  addedBy: string;
}