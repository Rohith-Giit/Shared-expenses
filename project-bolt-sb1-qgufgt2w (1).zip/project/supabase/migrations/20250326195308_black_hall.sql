/*
  # Financial Management Schema

  1. New Tables
    - `accounts`
      - Primary account information with real-time balance tracking
    - `transactions`
      - All financial transactions (income, expenses)
    - `savings`
      - Savings goals and tracking
    - `monthly_balances`
      - Historical monthly balance data for charts
    - `users`
      - Extended user profile data with unique codes

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to access their own data
*/

-- Users table for unique codes
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  unique_code text UNIQUE,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

-- Accounts table
CREATE TABLE IF NOT EXISTS accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  balance decimal NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE accounts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own account"
  ON accounts
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Transactions table
CREATE TABLE IF NOT EXISTS transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  type text NOT NULL CHECK (type IN ('income', 'expense')),
  amount decimal NOT NULL,
  description text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own transactions"
  ON transactions
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id);

-- Savings table
CREATE TABLE IF NOT EXISTS savings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  amount decimal NOT NULL DEFAULT 0,
  target_amount decimal,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE savings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own savings"
  ON savings
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id);

-- Monthly balances for chart data
CREATE TABLE IF NOT EXISTS monthly_balances (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  month date NOT NULL,
  balance decimal NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE monthly_balances ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own monthly balances"
  ON monthly_balances
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Function to update account balance
CREATE OR REPLACE FUNCTION update_account_balance()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE accounts
    SET balance = CASE
      WHEN NEW.type = 'income' THEN balance + NEW.amount
      WHEN NEW.type = 'expense' THEN balance - NEW.amount
    END,
    updated_at = now()
    WHERE user_id = NEW.user_id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to automatically update account balance
CREATE TRIGGER update_balance_on_transaction
  AFTER INSERT ON transactions
  FOR EACH ROW
  EXECUTE FUNCTION update_account_balance();

-- Function to update monthly balance
CREATE OR REPLACE FUNCTION update_monthly_balance()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO monthly_balances (user_id, month, balance)
  VALUES (
    NEW.user_id,
    date_trunc('month', NEW.updated_at),
    NEW.balance
  )
  ON CONFLICT (user_id, month) DO UPDATE
  SET balance = EXCLUDED.balance;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to automatically update monthly balance
CREATE TRIGGER update_monthly_balance_on_account_change
  AFTER UPDATE OF balance ON accounts
  FOR EACH ROW
  EXECUTE FUNCTION update_monthly_balance();